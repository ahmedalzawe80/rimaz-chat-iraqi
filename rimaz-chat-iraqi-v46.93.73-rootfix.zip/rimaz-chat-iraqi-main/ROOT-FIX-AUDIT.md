# Rimaz Chat — Root-Fix Audit v46.93.73

Date: 2026-11-23

## Scope

This is a source-level repair of the uploaded v46.93.72 archive. It preserves existing chat features and persistent database compatibility. Previously confirmed anti-spam/session cleanup, restore staging, room indexing, and socket-ownership fixes were retained rather than rewritten.

## 1. Database save pressure — root change

**Before:** `save()` serialized the complete database object synchronously and atomically replaced `data.json` on every save. This repeated work for unrelated updates and scaled with total database size.

**Now:**
- A tracking proxy observes nested object and array mutations and records changed paths.
- `save()` serializes only those changed paths into a versioned append-only journal (`data.json.journal`), not the entire database.
- The append is synchronous to preserve existing route rollback behavior; the record is fsynced before it is treated as committed.
- Journal records replay at startup. Patch paths are validated and unsafe prototype-related paths are rejected.
- A malformed journal tail is copied to a recovery file and replay stops at the last valid record; the valid prefix is retained.
- Failed appends attempt to truncate back to the prior journal size. If that rollback itself fails, writes are blocked rather than continuing against a damaged journal.
- The journal is compacted after 160 records or 8 MiB into an atomic JSON snapshot, followed by journal truncation. Directory syncing is attempted after snapshot replacement.
- Restore commits compact the new snapshot when possible.
- Transient private-message history is excluded from journal writes, compacted snapshots, and database/full backup exports.

The on-disk base remains JSON, so existing database compatibility and external recovery tooling are preserved. The new journal is stored beside it in the same persistent `DATA_DIR`.

## 2. Presence broadcast cost

- Each valid active session's display projection (profile, likes, rank/role, VIP, member number, room, country, and display name) is calculated once per presence context.
- Online user lists and room snapshots are cached for the same viewer account and hidden-presence capability, so duplicate tabs do not rebuild identical projections.
- The server still filters each viewer's visibility; ghost/hidden/self/staff rules are unchanged. For many distinct viewers, the visibility-filtering work is still proportional to viewers × active sessions, but expensive projection work and duplicate-tab broadcasts are reduced.

## 3. Homepage SEO cost

- The selected homepage HTML is read once at startup.
- Rendered SEO HTML is cached by site name, tagline, and canonical origin.
- Requests reuse the cached string; SEO replacements run again only when those settings change.

## 4. Existing anti-spam cleanup

The v46.93.72 anti-spam state lifecycle fix was retained: session state is removed after reconnect grace/session cleanup and the orphan sweep remains as a second cleanup path. It was not unnecessarily rewritten.

## 5. Regression checks

- `node --check server.js`: passed.
- `node --check verify.js`: passed.
- `npm test` / `node verify.js`: **451 checks passed** on local Node.js v22.16.0.
- Runtime fixtures cover changed-path journal writes, append recovery, private-message exclusion, compaction, malformed-tail isolation, presence projection reuse, and cache reuse.
- `index.html` and `public/index.html` are byte-identical (SHA-256: `680596fbc59c4911d7901b3ba01a529f7e825ccdacb68f090222a6bc443f5757`).
- The two redundant nested placeholder files and the embedded older v46.93.72 ZIP were removed from the delivery archive. The root placeholder `data.json` remains; it is not the live database.

## 6. Synthetic serialization comparison

A local microbenchmark using a synthetic database with 25,000 messages and a ~4.43 MB full JSON snapshot, median of five runs:

- Full snapshot stringify: **15.378 ms**, **4,430,787 bytes**.
- Example two-leaf journal record: **0.004 ms**, **165 bytes**.
- Approximate stringify-time ratio in this synthetic test: **4,299×**.

This is a microbenchmark of serialization payloads only—not an end-to-end production load test, and it does not include filesystem latency or journal compaction.

## 7. Limits / deployment caution

- The app remains designed for one server process using one persistent data directory; this journal is not a multi-writer distributed database.
- Compaction still serializes the full database occasionally, so a very large snapshot can temporarily block the event loop. Normal saves are incremental.
- Live Deplexo was not accessed or modified. The deployed Node runtime reported previously was v20.20.2; the local verification runtime was v22.16.0. No production data or uploads were included in this archive.
- Deploy the source update while preserving the existing persistent `DATA_DIR`, `data.json`, uploads, and private-media storage. Do not replace live storage with the ZIP's placeholder `data.json`.
